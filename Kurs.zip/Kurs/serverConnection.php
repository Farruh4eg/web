<?php
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $servername = "172.20.8.5"; 
    $username = "st2996_26"; 
    $password = "pwd2996_26";
   
    $database = "kurs";
   
     // Create a connection 
     $conn = mysqli_connect($servername, 
         $username, $password, $database);
   
   
    if($conn) {
        
    } 
    else {
        die("Error". mysqli_connect_error()); 
    } 
?>