<?php
session_start();
include_once('connection.php');

if (!isset($_SESSION["count"])) {
    $_SESSION["logged_in"] = false;
} else {
    $_SESSION["logged_in"] = true;
}
?>

<?php
$sql = "SELECT * FROM Dela";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php
echo '<div class="test" style="gap:10px">';
foreach ($result as $row) {
    echo '<div>';
    echo '<p>' . $row['nazvanie'] .'</p>';
    if($row['prioritet'] == '2') {
        echo '<p>Приоритет:</p>';
        echo '<p style="color: red;">Высокий</p>';
    } else if($row['prioritet'] == '1') {
        echo '<p>Приоритет:</p>';
        echo '<p style="color: orange;">Средний</p>';
    } else if($row['prioritet'] == '0') {
        echo '<p>Приоритет:</p>';
        echo '<p style="color: green;">Низкий</p>';
    }
    echo '<p>' . $row['kategoriya'] .'</p>';
}
echo '</div>';
?>