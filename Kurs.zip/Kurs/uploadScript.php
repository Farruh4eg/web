<?php
$conn = new PDO("mysql:host=172.20.8.5;dbname=kurs", 'st2996_26', 'pwd2996_26');

$query = "
INSERT INTO Dela VALUES (null, :delo_nazv, :delo_prioritet, :delo_kategoriya);";

$upload=$conn->prepare($query);

$upload->execute(['delo_nazv'=>$_POST['delo_nazv'], 'delo_prioritet'=>$_POST['delo_prioritet'], 'delo_kategoriya'=>$_POST['delo_kategoriya']]);

header("Location: ./upload.php");