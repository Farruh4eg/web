<?php
session_start();
include_once('connection.php');
?>

<?php
echo "
<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset='UTF-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Загрузить</title>
    <link rel='icon' type='image/x-icon' href='images/image 2.png'>
    <link rel='stylesheet' href='uploadstyle.css'>
    <script defer src='script.js'></script>
</head>

<body>
    <nav class='navBar'>
        <div style='display: flex; align-content: center; align-items: center;'>
            <a href='./Library.php'>
                    <img class='logoImage' src='images/image 2.svg' alt='logo'>
            </a>
        </div>
        <button onclick='changeThemeColor()' id='changeThemeImage' class='changeThemeButton'>
            <img src='images/sun.png' alt='theme'>
        </button>
    </nav>
    <form action='uploadScript.php' method='post' style='font-family:Montserrat;'>
        <div class='container'>
            <input type='text' name='delo_nazv' placeholder='Название дела'>
            <input type='text' name='delo_prioritet' placeholder='Приоритет дела' width='max-content'>
            <input type='text' name='delo_kategoriya' placeholder='Категория дела'>
            <div class='clearfix'>
                <button type='submit' class='submitbtn'>Сохранить</button>
            </div>
        </div>
    </form>
</body>

</html>";
?>