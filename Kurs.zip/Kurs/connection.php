<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn = "";

try {
    $servername = "172.20.8.5";
    $dbname = "kurs";
    $username = "st2996_26";
    $password = "pwd2996_26";

    $conn = new PDO(
        "mysql:host=$servername; dbname=kurs",
        $username,
        $password
    );

    $conn->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>